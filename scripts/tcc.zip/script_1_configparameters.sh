##--> Definir como será essa estrutura de arquivo; --/boot/config.cfg

pvid=ddxw12              ##PVID Adicionado no webservice
host=172.30.247.1        ##Servidor HOST webservice
user=root				 ##User para conexão do device
senha='an@box&98'        ##senha definida para conexão entre o usuário do rasp e o webservice






